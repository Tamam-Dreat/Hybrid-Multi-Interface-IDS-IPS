#!/bin/bash

IP=$1

iptables -A INPUT -s $IP -j DROP

echo "$(date) BLOCKED $IP" >> /var/log/blocked_ips.log
