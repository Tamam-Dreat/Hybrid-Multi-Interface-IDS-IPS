#!/bin/bash

# Clear old rules
iptables -F
iptables -X

# Allow localhost and established connections
iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT

# Allow Flask service (subscribe/upload)
iptables -A INPUT -p tcp --dport 5000 -j ACCEPT

# Allow approved subscribers on HTTP
while read ip; do
    iptables -A INPUT -p tcp -s "$ip" --dport 80 -j ACCEPT
done < /etc/allowed_ips.txt

# Block all other HTTP traffic
iptables -A INPUT -p tcp --dport 80 -j DROP
